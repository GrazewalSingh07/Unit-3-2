   function navbar(){
     return `<h1>Masai News</h1>
     <div>
      <a href="#"><p>Login</p></a>
         <input type="search" placeholder="Search News" id="search_box"/>
         <a href="#"><p>Start Ups</p></a> 
         <a href="#"><p>News Letters</p></a>
         <a href="#"><p>Audio</p></a> 
         <a href="#"><p>Video</p></a> 
     </div>`
 }
 export default navbar